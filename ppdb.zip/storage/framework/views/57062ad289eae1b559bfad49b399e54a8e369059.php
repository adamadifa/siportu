<option value="">Kabupaten/Kota</option>
<?php $__currentLoopData = $kota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option <?php if($id_kota == $k->id): ?>
        selected
        <?php endif; ?> value="<?php echo e($k->id); ?>"><?php echo e($k->regc_name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\ppdb\resources\views/loaddata/showbyprovinces.blade.php ENDPATH**/ ?>