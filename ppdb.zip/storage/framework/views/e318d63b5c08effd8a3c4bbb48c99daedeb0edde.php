<?php $__env->startSection('titlepage', 'Data Pembiayaan'); ?>
<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">Konfirmasi Pembayaran</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/pendaftar">Konfirmasi Pembayaran</a></li>
                            <li class="breadcrumb-item"><a href="#">Konfirmasi Pembayaran</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-body">

    <div class="col-md-12">
        <form class="form" action="/pembayaran/<?php echo e(\Crypt::encrypt(Auth::guard('pendaftaronline')->user()->no_pendaftaran)); ?>/store" method="POST">
            <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-md-6 col-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Konfirmasi Pembayaran</h4>
                                </div>
                                <div class="card-content">
                                    <div class="card-body">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-body">

                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'No. KK','value' => ''.e($pendaftar->no_pendaftaran).'','field' => 'no_kk','icon' => 'feather icon-credit-card','readonly' => 'true']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'No. KK','value' => ''.e($pendaftar->no_pendaftaran).'','field' => 'no_kk','icon' => 'feather icon-credit-card','readonly' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Nama Lengkap','value' => ''.e($pendaftar->nama_lengkap).'','field' => 'nama_lengkap','icon' => 'feather icon-user','readonly' => 'true']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Nama Lengkap','value' => ''.e($pendaftar->nama_lengkap).'','field' => 'nama_lengkap','icon' => 'feather icon-user','readonly' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Tanggal Bayar','field' => 'tgl_bayar','icon' => 'feather icon-calendar','datepicker' => 'true']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Tanggal Bayar','field' => 'tgl_bayar','icon' => 'feather icon-calendar','datepicker' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Dari Bank','field' => 'bank','icon' => 'fa fa-building-o']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Dari Bank','field' => 'bank','icon' => 'fa fa-building-o']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Pemilik Rekening','field' => 'pemilik_rekening','icon' => 'feather icon-user']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Pemilik Rekening','field' => 'pemilik_rekening','icon' => 'feather icon-user']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Biaya Pendaftaran','value' => ''.e(number_format($pendaftar->biaya_pendaftaran,'0','','.')).'','field' => 'biaya_pendaftaran','icon' => 'fa fa-money','readonly' => 'true']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Biaya Pendaftaran','value' => ''.e(number_format($pendaftar->biaya_pendaftaran,'0','','.')).'','field' => 'biaya_pendaftaran','icon' => 'fa fa-money','readonly' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12">
                                                    <button type="submit" class="btn btn-primary btn-block mr-1 mb-1 btn-block">Konfirmasi Pembayaran</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-4 col-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-content">
                                    <div class="card-body">
                                        Silahkan Melakukan Pembayaran Sejumlah <b>Rp. <?php echo e(number_format($pendaftar->biaya_pendaftaran,'0','','.')); ?></b>
                                        No. Rek <b> BSI : 7085588887</b> an. <b>Pesantren Persis 80 Ciamis</b> <br>
                                        <img src="<?php echo e(asset('app-assets/images/infopembayaran.jpg')); ?>" width="400x" height="400px" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </form>
        <div class="row">
            <div class="col-md-10 col-12">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-content">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>No. Transaksi</th>
                                                <th>Tanggal</th>
                                                <th>Bank</th>
                                                <th>Pemilik Rekening</th>
                                                <th>Jumlah Bayar</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($d->no_transaksi); ?></td>
                                                <td><?php echo e($d->tgl_bayar); ?></td>
                                                <td><?php echo e($d->bank); ?></td>
                                                <td><?php echo e($d->pemilik_rekening); ?></td>
                                                <td style="text-align: right"><?php echo e(number_format($d->biaya_pendaftaran,'0','','.')); ?></td>
                                                <td>
                                                    <?php if($d->status=="0"): ?>
                                                    <span class="badge badge-danger">Menunggu Konfirmasi</span>
                                                    <?php else: ?>
                                                    <span class="badge badge-success">Sudah Diverivikasi</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($d->status=="0"): ?>
                                                    <form method="POST" class="deleteform" action="/pembayaran/<?php echo e(Crypt::encrypt($d->no_transaksi)); ?>/delete">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <a class="delete-confirm ml-1">
                                                            <i class="feather icon-trash danger"></i>
                                                        </a>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('myscript'); ?>
<script>
    $(function() {
        $('.delete-confirm').on('click', function(event) {
            event.preventDefault();
            const url = $(this).attr('href');
            swal({
                title: 'Anda Yakin?'
                , text: 'Data ini akan didelete secara permanen!'
                , icon: 'warning'
                , buttons: ["Cancel", "Yes!"]
            , }).then(function(value) {
                if (value) {
                    $(".deleteform").submit();
                }
            });
        });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.midone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ppdb\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>