<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
    <h4 class="alert-heading">Success</h4>
    <p class="mb-0">
        <?php echo e($message); ?>

    </p>
</div>

<?php endif; ?>
<?php if($message = Session::get('failed')): ?>

<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning" role="alert">
    <h4 class="alert-heading">Warning</h4>
    <p class="mb-0">
        <?php echo e($message); ?>

    </p>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ppdb\resources\views/layouts/notification.blade.php ENDPATH**/ ?>