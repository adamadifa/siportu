<?php $__env->startSection('titlepage', 'Detail Simpanan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-9 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="col-12">
                        <h2 class="content-header-title float-left mb-0">Detail Simpanan</h2>
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="/simpanan">Simpanan</a></li>
                                <li class="breadcrumb-item"><a href="#">Detail Simpanan</a></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content-body">
            <!-- page users view start -->
            <section class="page-users-view">
                <div class="row">
                    <!-- account start -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="card-title">Anggota</div>
                            </div>
                            <div class="card-body">
                                <div class="row">

                                    <div class="users-view-image">
                                        <img src="<?php echo e(asset('app-assets/images/no photo.png')); ?>"
                                            class="users-avatar-shadow w-100 rounded mb-2 pr-2 ml-1" alt="avatar">
                                    </div>

                                    <div class="col-md-3">
                                        <table class="table">
                                            <tr>
                                                <td class="font-weight-bold"><i class="fa fa-barcode mr-1"></i>No Anggota
                                                </td>
                                                <td><?php echo e($anggota->no_anggota); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="font-weight-bold"><i class="feather icon-credit-card mr-1"></i>
                                                    NIK</td>
                                                <td><?php echo e($anggota->nik); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="font-weight-bold"><i class="feather icon-user mr-1"></i>Nama
                                                    Lengkap</td>
                                                <td><?php echo e($anggota->nama_lengkap); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-md-3">
                                        <table class="table">
                                            <tr>
                                                <td class="font-weight-bold"><i class="feather icon-calendar mr-1"></i>TTL
                                                </td>
                                                <td><?php echo e($anggota->tempat_lahir); ?>,
                                                    <?php echo e(date(
                                                        "d M
                                                                                                                                                        Y",
                                                        strtotime($anggota->tanggal_lahir),
                                                    )); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="font-weight-bold"><i class="feather icon-phone mr-1"></i>No HP
                                                </td>
                                                <td><?php echo e($anggota->no_hp); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="font-weight-bold"><i class="feather icon-map mr-1"></i>Alamat
                                                </td>
                                                <td><?php echo e($anggota->alamat); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="col-md-3">

                                        <table class="table ">
                                            <?php
                                                $total = 0;
                                            ?>
                                            <?php $__currentLoopData = $saldosimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $total += $d->jumlah;
                                                ?>
                                                <tr>
                                                    <td class="font-weight-bold"> <?php echo e($d->kode_simpanan); ?> -
                                                        <?php echo e($d->nama_simpanan); ?>

                                                    </td>
                                                    <td class="text-right">
                                                        <?php echo e(number_format($d->jumlah, '0', '', '.')); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- account end -->
                <div class="row">
                    <div class="col-md-6">
                        <a href="#" id="inputsetoran" class="btn btn-relief-primary waves-effect waves-light btn-block"><i
                                class="feather icon-corner-down-right mr-1"></i> Setoran</a>
                    </div>
                    <div class="col-md-6">
                        <a href="#" id="inputpenarikan" class="btn btn-relief-danger waves-effect waves-light btn-block"><i
                                class="feather icon-corner-down-left mr-1"></i> Penarikan</a>
                    </div>
                </div>
        </div>
        <!-- information start -->
        <div class="row">
            <div class="col-md-12 col-12 mt-2">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title mb-2"><i class="feather icon-folder mr-1"></i>Data Mutasi</div>
                    </div>
                    <div class="card-body">
                        <form action="">
                            <div class="row">
                                <div class="col-md-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Dari','field' => 'dari','icon' => 'feather icon-calendar','datepicker' => 'true','value' => ''.e(Request('dari')).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Dari','field' => 'dari','icon' => 'feather icon-calendar','datepicker' => 'true','value' => ''.e(Request('dari')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Sampai','field' => 'sampai','icon' => 'feather icon-calendar','datepicker' => 'true','value' => ''.e(Request('sampai')).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Sampai','field' => 'sampai','icon' => 'feather icon-calendar','datepicker' => 'true','value' => ''.e(Request('sampai')).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                                <div class="col-md-2">
                                    <button class="btn btn-primary"><i class="feather icon-search mr2"></i>
                                        Tampilkan</button>
                                </div>
                            </div>
                        </form>
                        <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php if($lastdata != null): ?>
                            <?php if($lastdata->jenis_transaksi == 'S'): ?>
                                <?php
                                    $setor = $lastdata->jumlah;
                                    $tarik = 0;

                                ?>
                            <?php else: ?>
                                <?php
                                    $setor = 0;
                                    $tarik = $d->jumlah;
                                ?>
                            <?php endif; ?>
                            <?php
                                $saldoawal = $lastdata->saldo;
                            ?>
                        <?php else: ?>
                            <?php
                                $saldoawal = 0;
                            ?>
                        <?php endif; ?>
                        <input type="hidden" id="ceksaldo" value="<?php echo e($saldoawal); ?>">
                        <table class="table table-bordered table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>NO TRANSAKSI</th>
                                    <th>TANGGAL</th>
                                    <th>JENIS SIMPANAN</th>
                                    <th>SETOR</th>
                                    <th>TARIK</th>
                                    <th>SALDO</th>
                                    <th>BERITA</th>
                                    <th>PETUGAS</th>
                                    <th></th>

                                </tr>
                                <tr>
                                    <th colspan="5" style="text-align: center">SALDO AWAL</th>
                                    <th style="text-align: right" id="saldoawal">
                                        <?php echo e(number_format($saldoawal, '0', '', '.')); ?>

                                    </th>
                                    <th colspan="3"></th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php

                                    $i = 1;
                                ?>
                                <?php $__currentLoopData = $datasimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($d->jenis_transaksi == 'S'): ?>
                                        <?php
                                            $setor = $d->jumlah;
                                            $tarik = 0;

                                        ?>
                                    <?php else: ?>
                                        <?php
                                            $setor = 0;
                                            $tarik = $d->jumlah;

                                        ?>
                                    <?php endif; ?>

                                    <?php if($d->kode_simpanan == '001'): ?>
                                        <?php
                                            $bg = 'bg-theme-1';
                                        ?>
                                    <?php elseif($d->kode_simpanan=="002"): ?>
                                        <?php
                                            $bg = 'bg-theme-29';
                                        ?>
                                    <?php elseif($d->kode_simpanan=="003"): ?>
                                        <?php
                                            $bg = 'bg-orange-400';
                                        ?>
                                    <?php endif; ?>

                                    <?php if($i == 1): ?>
                                        <?php
                                            $id1 = 'saldo';
                                            $id2 = 'setor';
                                            $id3 = 'tarik';
                                        ?>
                                    <?php else: ?>
                                        <?php
                                            $id1 = '';
                                            $id2 = '';
                                            $id3 = '';
                                        ?>
                                    <?php endif; ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($d->no_transaksi); ?></td>
                                        <td class="text-center"><?php echo e(date('d-m-Y', strtotime($d->tgl_transaksi))); ?></td>
                                        <td> <?php echo e($d->kode_simpanan); ?> - <?php echo e($d->nama_simpanan); ?></td>
                                        <td class="text-right success" id="<?php echo e($id2); ?>">
                                            <?php echo e(number_format($setor, '0', '', '.')); ?>

                                        </td>
                                        <td class="text-right danger" id="<?php echo e($id3); ?>">
                                            <?php echo e(number_format($tarik, '0', '', '.')); ?>

                                        </td>
                                        <td class="text-right" id="<?php echo e($id1); ?>" style="font-weight: bold">
                                            <?php echo e(number_format($d->saldo, '0', '', '.')); ?>

                                        </td>
                                        <td class="text-center">
                                            <?php if(!empty($d->berita)): ?>
                                                <?php echo e($d->berita); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center"><?php echo e($d->name); ?></td>
                                        <td>
                                            <?php if($i == $totalrow): ?>
                                                <div class="flex justify-center items-center">
                                                    <form method="POST" class="deleteform"
                                                        action="/simpanan/<?php echo e(Crypt::encrypt($d->no_transaksi)); ?>/delete">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <a class="delete-confirm"><i
                                                                class="feather icon-trash danger"></i></a>
                                                    </form>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php
                                        $i = $i + 1;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($datasimpanan->links('vendor.pagination.vuexy')); ?>

                    </div>
                </div>
            </div>
        </div>
        <!-- information start -->
    </div>

    </section>
    <!-- page users view end -->
    </div>
    </div>
    <div class="modal fade" id="modalsetoran" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" id="frmSimpanan" action="/simpanan/store" class="validate-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="no_anggota" id="no_anggota"
                            value="<?php echo e(\Crypt::encrypt($anggota->no_anggota)); ?>">
                        <input type="hidden" name="jenis_transaksi" id="jenis_transaksi">
                        <div class="col-12">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'No. Transaksi (Auto)','field' => 'no_transaksi','icon' => 'feather icon-maximize']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'No. Transaksi (Auto)','field' => 'no_transaksi','icon' => 'feather icon-maximize']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Tanggal Transaksi','field' => 'tgl_transaksi','icon' => 'feather icon-calendar','datepicker' => 'true']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Tanggal Transaksi','field' => 'tgl_transaksi','icon' => 'feather icon-calendar','datepicker' => 'true']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 mb-2">
                            <select class="form-control" name="kode_simpanan" id="kode_simpanan">
                                <option value="">Jenis Simpanan</option>
                                <?php $__currentLoopData = $simpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($d->kode_simpanan); ?>"><?php echo e($d->kode_simpanan); ?> -
                                        <?php echo e($d->nama_simpanan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Jumlah','field' => 'jumlah','icon' => 'feather icon-inbox']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Jumlah','field' => 'jumlah','icon' => 'feather icon-inbox']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                        <div class="col-12 mb-2">
                            <textarea name="berita" placeholder="Berita" class="form-control" id="berita" cols="30"
                                rows="5"></textarea>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="button" data-dismiss="modal" class="btn btn-danger">Batalkan</button>
                            </div>
                        </div>
                    </form>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('myscript'); ?>
    <script type="text/javascript">
        var jumlah = document.getElementById('jumlah');
        jumlah.addEventListener('keyup', function(e) {
            // tambahkan 'Rp.' pada saat form di ketik
            // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
            jumlah.value = formatRupiah(this.value, '');
        });

        /* Fungsi formatRupiah */
        function formatRupiah(angka, prefix) {
            var number_string = angka.replace(/[^,\d]/g, '').toString(),
                split = number_string.split(','),
                sisa = split[0].length % 3,
                rupiah = split[0].substr(0, sisa),
                ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            // tambahkan titik jika yang di input sudah menjadi angka ribuan
            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix == undefined ? rupiah : (rupiah ? rupiah : '');
        }
    </script>
    <script>
        $(function() {
            function addCommas(nStr) {
                nStr += '';
                x = nStr.split('.');
                x1 = x[0];
                x2 = x.length > 1 ? '.' + x[1] : '';
                var rgx = /(\d+)(\d{3})/;
                while (rgx.test(x1)) {
                    x1 = x1.replace(rgx, '$1' + '.' + '$2');
                }
                return x1 + x2;
            }

            function loadsaldo() {
                var saldo = $("#saldo").text();
                var setor = $("#setor").text();
                var tarik = $("#tarik").text();
                var sa = $("#ceksaldo").val();
                var saldonumber = saldo.replace(/\./g, "");
                var setornumber = setor.replace(/\./g, "");
                var tariknumber = tarik.replace(/\./g, "");
                var saldoawal = parseInt(saldonumber) + parseInt(tariknumber) - parseInt(setornumber);
                console.log(sa);
                if (sa == 0) {
                    $("#saldoawal").text(addCommas(saldoawal));
                }

            }
            loadsaldo();
            $("#inputsetoran").click(function(e) {
                e.preventDefault();
                $("#modalsetoran").modal("show");
                $("#jenis_transaksi").val("S");
                $("#exampleModalCenterTitle").text("Input Setoran");

            });

            $("#inputpenarikan").click(function(e) {
                e.preventDefault();
                $("#modalsetoran").modal("show");
                $("#jenis_transaksi").val("T");
                $("#exampleModalCenterTitle").text("Input Penarikan");
            });

            $("#frmSimpanan").submit(function() {
                var kode_simpanan = $("#kode_simpanan").val();
                var jumlah = $("#jumlah").val();
                var tgl_transaksi = $("#tgl_transaksi").val();
                //alert('test');
                if (kode_simpanan == "") {
                    swal("Oops", "Kode Simpanan Harus Diisi !", "warning");
                    return false;
                } else if (jumlah == "") {
                    swal("Oops", "Jumlah Harus Diisi !", "warning");
                    return false;
                } else if (tgl_transaksi == "") {
                    swal("Oops", "Tanggal Harus Diisi !", "warning");
                    return false;
                }
            });

            $('.delete-confirm').on('click', function(event) {
                event.preventDefault();
                const url = $(this).attr('href');
                swal({
                    title: 'Anda Yakin?',
                    text: 'Data ini akan didelete secara permanen!',
                    icon: 'warning',
                    buttons: ["Cancel", "Yes!"],
                }).then(function(value) {
                    if (value) {
                        $(".deleteform").submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.midone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kopontren\resources\views/simpanan/show.blade.php ENDPATH**/ ?>