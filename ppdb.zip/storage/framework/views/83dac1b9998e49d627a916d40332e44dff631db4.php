<!-- BEGIN: Main Menu-->
<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand"
                    href="<?php echo e(asset('html/ltr/vertical-menu-template/index.html')); ?>">
                    <div><img src="<?php echo e(asset('dist/images/logo.png')); ?>" width="60px" height="50px" alt=""></div>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i
                        class="feather icon-x d-block d-xl-none font-medium-4 primary toggle-icon"></i><i
                        class="toggle-icon feather icon-disc font-medium-4 d-none d-xl-block collapse-toggle-icon primary"
                        data-ticon="icon-disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" nav-item"><a href="/dashboard"><i class="feather icon-home"></i><span class="menu-title"
                        data-i18n="Dashboard">Dashboard</span></a>
            </li>
            <li class=" navigation-header"><span>Data Master</span>
            <li class=" nav-item">
                <a href="#"><i class="feather icon-grid"></i><span class="menu-title">Data Master</span></a>
                <ul class="menu-content">
                    <li class="<?php echo e(request()->is(['anggota', 'anggota/*']) ? 'active' : ''); ?>"><a href="/anggota"><i
                                class="feather icon-users"></i><span class="menu-item">Anggota</span></a></li>
                    <li class="<?php echo e(request()->is(['jenissimpanan', 'jenissimpanan/*']) ? 'active' : ''); ?>"><a
                            href="/jenissimpanan"><i class="feather icon-book"></i><span class="menu-item">Jenis
                                Simpanan</span></a></li>
                    <li class="<?php echo e(request()->is(['tabungan', 'tabungan/*']) ? 'active' : ''); ?>"><a href="/tabungan"><i
                                class="feather icon-book"></i><span class="menu-item">Jenis
                                Tabungan</span></a>
                    </li>
                    <li class="<?php echo e(request()->is(['jenispembiayaan', 'jenispembiayaan/*']) ? 'active' : ''); ?>"><a
                            href="/jenispembiayaan"><i class="fa fa-balance-scale"></i><span class="menu-item">Jenis
                                Pembiayaan</span></a>
                    </li>
                </ul>
            </li>
            <li class=" navigation-header"><span>Data Transaksi</span>
            <li class=" nav-item <?php echo e(request()->is(['simpanan', 'simpanan/*']) ? 'active' : ''); ?>">
                <a href="/simpanan"><i class="fa fa-book"></i><span class="menu-title">Simpanan</span></a>
            </li>
            <li class=" nav-item <?php echo e(request()->is(['rekening', 'rekening/*']) ? 'active' : ''); ?>">
                <a href="/rekening"><i class="fa fa-book"></i><span class="menu-title">Tabungan</span></a>
            </li>
            <li class=" nav-item <?php echo e(request()->is(['pembiayaan', 'pembiayaan/*']) ? 'active' : ''); ?>">
                <a href="/pembiayaan"><i class="fa fa-balance-scale"></i><span class="menu-title">Pembiayaan</span></a>
            </li>
        </ul>
    </div>
</div>
<!-- END: Main Menu-->
<?php /**PATH C:\xampp\htdocs\kopontren\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>