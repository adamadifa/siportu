<option value="">Kecamatan</option>
<?php $__currentLoopData = $kecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option <?php if($id_kecamatan == $k->id): ?>
        selected
        <?php endif; ?> value="<?php echo e($k->id); ?>"><?php echo e($k->dist_name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\ppdb\resources\views/loaddata/showbyregencies.blade.php ENDPATH**/ ?>