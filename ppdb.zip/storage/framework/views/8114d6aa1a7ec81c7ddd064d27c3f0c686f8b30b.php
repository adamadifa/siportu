<?php $__env->startSection('titlepage','Data Anggota'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">Data Anggota</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/anggota">Anggota</a>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <!-- Data list view starts -->
        <!-- DataTable starts -->
        <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <a href="/anggota/create" class="btn btn-primary"><i
                                class="feather icon-user-plus mr-2"></i>Tambah
                            Anggota</a>
                    </div>
                    <div>
                        <form action="/anggota">
                            <div class=" form-label-group position-relative has-icon-left">
                                <input type="text" value="<?php echo e(Request('cari')); ?>" id="cari" name="cari"
                                    class="form-control" name="fname-floating-icon" placeholder="Search">
                                <div class="form-control-position">
                                    <i class="feather icon-search"></i>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>KODE SIMPANAN</th>
                                <th>NAMA SIMPANAN</th>
                                <th>NAMA LENGKAP</th>
                                <th>TTL</th>
                                <th>No. HP</th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration + $anggota->firstItem() - 1); ?></td>
                                <td class=""><?php echo e($d->no_anggota); ?></td>
                                <td class=""><?php echo e($d->nik); ?></td>
                                <td>
                                    <a href=""><?php echo e($d->nama_lengkap); ?></a>
                                </td>
                                <td><?php echo e($d->tempat_lahir); ?>, <?php echo e($d->tanggal_lahir); ?></td>
                                <td>
                                    <?php echo e($d->no_hp); ?>

                                </td>
                                <td class="table-report__action w-56">
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a class="ml-1" href="/anggota/<?php echo e(\Crypt::encrypt($d->no_anggota)); ?>/edit"><i
                                                class="feather icon-edit"></i></a>
                                        <a class="ml-1" href="/anggota/<?php echo e(\Crypt::encrypt($d->no_anggota)); ?>/show"><i
                                                class="feather icon-user info"></i></a>
                                        <form method="POST" class="deleteform"
                                            action="/anggota/<?php echo e(Crypt::encrypt($d->no_anggota)); ?>/delete">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <a class="delete-confirm ml-1">
                                                <i class="feather icon-trash danger"></i>
                                            </a>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
                <?php echo e($anggota->links('vendor.pagination.vuexy')); ?>

                <!-- DataTable ends -->
            </div>
        </div>
        <!-- Data list view end -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('myscript'); ?>
<script>
    $(function(){
        $('.delete-confirm').on('click', function (event) {
            event.preventDefault();
            const url = $(this).attr('href');
            swal({
                title: 'Anda Yakin?',
                text: 'Data ini akan didelete secara permanen!',
                icon: 'warning',
                buttons: ["Cancel", "Yes!"],
            }).then(function(value) {
                if (value) {
                   $(".deleteform").submit();
                }
            });
        });
      });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.midone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kopontren\resources\views/anggota/index.blade.php ENDPATH**/ ?>