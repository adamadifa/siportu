<div class="form-group  <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"">
    <div class=" form-label-group position-relative has-icon-left">
    <div class="controls">
        <input type="text" autocomplete="off" id="<?php echo e($field); ?>" <?php if(isset($value)): ?> value="<?php echo e(old($field) ? old($field) : $value); ?>" <?php else: ?> value="<?php echo e(old($field)); ?>" <?php endif; ?> class="form-control <?php if(isset($datepicker)): ?> pickadate-months-year picker__input <?php endif; ?>" name="<?php echo e($field); ?>" <?php if(isset($readonly)): ?> readonly <?php endif; ?>" placeholder="<?php echo e($label); ?>">
        <div class="form-control-position">
            <i class="<?php echo e($icon); ?>"></i>
        </div>
        <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="help-block">
            <ul role="alert">
                <li><?php echo e($message); ?></li>
            </ul>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\ppdb\resources\views/components/inputtext.blade.php ENDPATH**/ ?>