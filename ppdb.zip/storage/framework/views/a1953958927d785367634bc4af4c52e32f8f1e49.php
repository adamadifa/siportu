<li>
    <a href="index.html" class="side-menu side-menu--active">
        <div class="side-menu__icon"> <i data-feather="home"></i> </div>
        <div class="side-menu__title"> Dashboard </div>
    </a>
</li>
<li>
    <a href="javascript:;" class="side-menu">
        <div class="side-menu__icon"> <i data-feather="layers"></i> </div>
        <div class="side-menu__title"> Data Master <i data-feather="chevron-down" class="side-menu__sub-icon"></i> </div>
    </a>
    <ul class="">
        <li>
            <a href="index.html" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="box"></i> </div>
                <div class="side-menu__title"> Data Barang</div>
            </a>
        </li>
        <li>
            <a href="simple-menu-dashboard.html" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="users"></i> </div>
                <div class="side-menu__title"> Data Salesman </div>
            </a>
        </li>
        <li>
            <a href="simple-menu-dashboard.html" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="users"></i> </div>
                <div class="side-menu__title"> Data Pelanggan </div>
            </a>
        </li>
        <li>
            <a href="simple-menu-dashboard.html" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="codepen"></i> </div>
                <div class="side-menu__title"> Data Cabang </div>
            </a>
        </li>
        <li>
            <a href="top-menu-dashboard.html" class="side-menu">
                <div class="side-menu__icon"> <i data-feather="truck"></i> </div>
                <div class="side-menu__title"> Data Kendaraan </div>
            </a>
        </li>
    </ul>
</li>
<?php /**PATH C:\xampp\htdocs\pacificv3\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>