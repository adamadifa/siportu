<?php $__env->startSection('titlepage', 'Data Tabungan Anggota'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">Data Tabungan</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/rekening">Tabungan</a>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <!-- Data list view starts -->
        <!-- DataTable starts -->
        <?php echo $__env->make('layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
                <div class="row mb-2">
                    <div class="col-md-12">
                        <a href="#" id="buatrekening" class="btn btn-primary"><i class="feather icon-file-text mr-2"></i>Buat Rekening</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form action="/rekening">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class=" form-label-group position-relative has-icon-left">
                                        <input type="text" value="<?php echo e(Request('nama')); ?>" id="nama" name="nama" class="form-control" name="fname-floating-icon" placeholder="Nama Anggota">
                                        <div class="form-control-position">
                                            <i class="feather icon-user"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <select class="form-control" name="kodetabungan" id="kodetabungan">
                                        <option value="">Jenis Tabungan</option>
                                        <?php $__currentLoopData = $tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(Request('kodetabungan')==$d->kode_tabungan): ?>
                                            selected
                                            <?php endif; ?>
                                            value="<?php echo e($d->kode_tabungan); ?>"><?php echo e($d->kode_tabungan); ?> -
                                            <?php echo e($d->nama_tabungan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary"><i class="feather icon-search mr-1"></i>Search</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>NO</th>
                                <th>NO REKENING</th>
                                <th class="text-center">KODE ANGGOTA</th>
                                <th>NAMA LENGKAP</th>
                                <th class="text-center">KODE TABUNGAN</th>
                                <th>JENIS TABUNGAN</th>
                                <th>SALDO</th>
                                <th>ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rekening; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration + $rekening->firstItem() - 1); ?></td>
                                <td><?php echo e($d->no_rekening); ?></td>
                                <td class="text-center"><?php echo e($d->no_anggota); ?></td>
                                <td><?php echo e($d->nama_lengkap); ?></td>
                                <td class="text-center"><?php echo e($d->kode_tabungan); ?></td>
                                <td><?php echo e($d->nama_tabungan); ?></td>
                                <td style="text-align:right"><?php echo e(number_format($d->saldo, '0', '', '.')); ?></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href="/rekening/<?php echo e(Crypt::encrypt($d->no_rekening)); ?>/show" class="primary"><i class="feather icon-book"></i></a>
                                        <form method="POST" class="deleteform" action="/rekening/<?php echo e(Crypt::encrypt($d->no_rekening)); ?>/delete">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <a class="delete-confirm ml-1">
                                                <i class="feather icon-trash danger"></i>
                                            </a>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($rekening->links('vendor.pagination.vuexy')); ?>

                </div>

                <!-- DataTable ends -->
            </div>
        </div>
        <!-- Data list view end -->
    </div>
</div>
<div class="modal fade" id="modalbuatrekening" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Buat Rekening</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" id="frmSimpanan" action="/rekening/store" class="frmRekening">
                    <?php echo csrf_field(); ?>
                    <div class="col-12">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'No. Rekening (Auto)','field' => 'no_rekening','icon' => 'feather icon-maximize','readonly' => 'true']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'No. Rekening (Auto)','field' => 'no_rekening','icon' => 'feather icon-maximize','readonly' => 'true']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                    <div class="col-12">
                        <input type="hidden" name="no_anggota" id="no_anggota">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputgroup','data' => ['label' => 'Anggota','field' => 'nama_lengkap','icon' => 'feather icon-user','readonly' => 'true']]); ?>
<?php $component->withName('inputgroup'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Anggota','field' => 'nama_lengkap','icon' => 'feather icon-user','readonly' => 'true']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    </div>
                    <div class="col-12 mb-2">
                        <select class="form-control" name="kode_tabungan" id="kode_tabungan">
                            <option value="">Jenis Tabungan</option>
                            <?php $__currentLoopData = $tabungan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($d->kode_tabungan); ?>"><?php echo e($d->kode_tabungan); ?> -
                                <?php echo e($d->nama_tabungan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="button" data-dismiss="modal" class="btn btn-danger">Batalkan</button>
                        </div>
                    </div>
                </form>
            </div>


        </div>
    </div>
</div>

<!-- Modal Data Anggota -->
<div class="modal fade text-left" id="modalanggota" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel17">Data Anggota</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <table class="table dataanggota" style="width:100%">
                    <thead>
                        <tr>
                            <th style="width:5%">No</th>
                            <th style="width:20%">No Anggota</th>
                            <th style="width:65%">Nama Lengkap</th>
                            <th style="width:10%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('myscript'); ?>

<script>
    $(function() {
        $('.delete-confirm').on('click', function(event) {
            event.preventDefault();
            const url = $(this).attr('href');
            swal({
                title: 'Anda Yakin?'
                , text: 'Data ini akan didelete secara permanen!'
                , icon: 'warning'
                , buttons: ["Cancel", "Yes!"]
            , }).then(function(value) {
                if (value) {
                    $(".deleteform").submit();
                }
            });
        });
        $("#no_anggota").autocomplete({
            source: function(request, response) {
                // Fetch data
                $.ajax({
                    url: "/anggota/getautocomplete"
                    , type: 'post'
                    , dataType: "json"
                    , data: {
                        _token: "<?php echo e(csrf_token()); ?>"
                        , search: request.term
                    }
                    , success: function(data) {
                        response(data);
                    }
                });
            }
            , select: function(event, ui) {
                $('#no_anggota').val(ui.item.label);
                var no_anggota = ui.item.val;
                alert(no_anggota);
                return false;
            }
        });

        $("#buatrekening").click(function(e) {
            e.preventDefault();
            $("#modalbuatrekening").modal({
                backdrop: 'static'
                , keyboard: false
            });
        });

        $("#search").click(function(e) {
            e.preventDefault();
            $("#modalanggota").modal({
                backdrop: 'static'
                , keyboard: false
            });
        });

        $("#no_anggota").autocomplete("option", "appendTo", ".frmRekening");


        var table = $('.dataanggota').DataTable({
            processing: true
            , serverSide: true
            , autoWidth: false,

            ajax: "<?php echo e(route('dataanggota')); ?>"
            , columns: [{
                    data: 'DT_RowIndex'
                    , name: 'DT_RowIndex'
                }
                , {
                    data: 'no_anggota'
                    , name: 'no_anggota'
                }
                , {
                    data: 'nama_lengkap'
                    , name: 'nama_lengkap'
                }
                , {
                    data: 'action'
                    , name: 'action'
                    , orderable: true
                    , searchable: true
                }
            , ]
        });

        $('.dataanggota tbody').on('click', 'a', function() {
            var no_anggota = $(this).attr("no-anggota");
            var nama_lengkap = $(this).attr("nama");
            $("#no_anggota").val(no_anggota);
            $("#nama_lengkap").val(nama_lengkap);
            $("#modalanggota .close").click();
        });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.midone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kopontren\resources\views/tabungan/listrekening.blade.php ENDPATH**/ ?>