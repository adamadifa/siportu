<?php $__env->startSection('titlepage', 'Data Anggota'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-left mb-0">Edit Anggota</h2>
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/anggota">Anggota</a></li>
                            <li class="breadcrumb-item"><a href="#">Edit Anggota</a></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content-body">
    <form class="form" action="/anggota/<?php echo e(\Crypt::encrypt($anggota->no_anggota)); ?>/update" method="POST">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Data Diri Anggota</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <?php echo csrf_field(); ?>
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Nomor Identitas','field' => 'nik','icon' => 'feather icon-credit-card','value' => ''.e($anggota->nik).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Nomor Identitas','field' => 'nik','icon' => 'feather icon-credit-card','value' => ''.e($anggota->nik).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Nama Lengkap','field' => 'nama_lengkap','icon' => 'feather icon-user','value' => ''.e($anggota->nama_lengkap).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Nama Lengkap','field' => 'nama_lengkap','icon' => 'feather icon-user','value' => ''.e($anggota->nama_lengkap).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Tempat Lahir','field' => 'tempat_lahir','icon' => 'feather icon-map','value' => ''.e($anggota->tempat_lahir).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Tempat Lahir','field' => 'tempat_lahir','icon' => 'feather icon-map','value' => ''.e($anggota->tempat_lahir).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-6">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Tanggal Lahir','field' => 'tanggal_lahir','icon' => 'feather icon-calendar','datepicker' => 'true','value' => ''.e($anggota->tanggal_lahir).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Tanggal Lahir','field' => 'tanggal_lahir','icon' => 'feather icon-calendar','datepicker' => 'true','value' => ''.e($anggota->tanggal_lahir).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group  <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <select name="jenis_kelamin" id="" class="form-control">
                                                    <option value="">Jenis Kelamin</option>
                                                    <option <?php if(isset($anggota->jenis_kelamin)): ?> <?php if(old('jenis_kelamin')): ?>
                                                        <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->jenis_kelamin == 'L' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('jenis_kelamin') == 'L' ? 'selected' : ''); ?>

                                                        <?php endif; ?> value="L">Laki - Laki</option>
                                                    <option <?php if(isset($anggota->jenis_kelamin)): ?> <?php if(old('jenis_kelamin')): ?>
                                                        <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->jenis_kelamin == 'P' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('jenis_kelamin') == 'P' ? 'selected' : ''); ?>

                                                        <?php endif; ?> value="P">Perempuan</option>
                                                </select>
                                                <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="help-block">
                                                    <ul role="alert">
                                                        <li><?php echo e($message); ?></li>
                                                    </ul>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group  <?php $__errorArgs = ['pendidikan_terakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <select name="pendidikan_terakhir" id="pendidikan_terakhir" class="form-control">
                                                    <option value="">Pendidikan Terakhir</option>
                                                    <option <?php if(isset($anggota->pendidikan_terakhir)): ?>
                                                        <?php if(old('pendidikan_terakhir')): ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'SD' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->pendidikan_terakhir == 'SD' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'SD' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        value="SD">
                                                        SD
                                                    </option>
                                                    <option <?php if(isset($anggota->pendidikan_terakhir)): ?> <?php if(old('pendidikan_terakhir')): ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'SMP' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->pendidikan_terakhir == 'SMP' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'SMP' ? 'selected' : ''); ?>

                                                        <?php endif; ?> value="SMP"> SMP </option>
                                                    <option <?php if(isset($anggota->pendidikan_terakhir)): ?> <?php if(old('pendidikan_terakhir')): ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'SMA' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->pendidikan_terakhir == 'SMA' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'SMA' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        value="SMA">SMA</option>
                                                    <option <?php if(isset($anggota->pendidikan_terakhir)): ?> <?php if(old('pendidikan_terakhir')): ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'D3' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->pendidikan_terakhir == 'D3' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'D3' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        value="D3">D3</option>
                                                    <option <?php if(isset($anggota->pendidikan_terakhir)): ?> <?php if(old('pendidikan_terakhir')): ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'S1' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->pendidikan_terakhir == 'S1' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'S1' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        value="S1"> S1 </option>
                                                    <option <?php if(isset($anggota->pendidikan_terakhir)): ?> <?php if(old('pendidikan_terakhir')): ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'S2' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->pendidikan_terakhir == 'S2' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('pendidikan_terakhir') == 'S2' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        value="S2">
                                                        S2
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['pendidikan_terakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="help-block">
                                                    <ul role="alert">
                                                        <li><?php echo e($message); ?></li>
                                                    </ul>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group <?php $__errorArgs = ['status_pernikahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <select name="status_pernikahan" id="status_pernikahan" class="form-control">
                                                    <option value="">Status Perkawinan</option>
                                                    <option <?php if(isset($anggota->status_pernikahan)): ?>
                                                        <?php if(old('status_pernikahan')): ?>
                                                        <?php echo e(old('status_pernikahan') == 'M' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->status_pernikahan == 'M' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('status_pernikahan') == 'M' ? 'selected' : ''); ?>

                                                        <?php endif; ?> value="M">
                                                        Menikah
                                                    </option>
                                                    <option <?php if(isset($anggota->status_pernikahan)): ?> <?php if(old('status_pernikahan')): ?>
                                                        <?php echo e(old('status_pernikahan') == 'BM' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->status_pernikahan == 'BM' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('status_pernikahan') == 'BM' ? 'selected' : ''); ?>

                                                        <?php endif; ?> value="BM">
                                                        Belum Menikah
                                                    </option>
                                                    <option <?php if(isset($anggota->status_pernikahan)): ?> <?php if(old('status_pernikahan')): ?>
                                                        <?php echo e(old('status_pernikahan') == 'JD' ? 'selected' : ''); ?>

                                                        <?php else: ?>
                                                        <?php echo e($anggota->status_pernikahan == 'JD' ? 'selected' : ''); ?>

                                                        <?php endif; ?>
                                                        <?php else: ?>
                                                        <?php echo e(old('status_pernikahan') == 'JD' ? 'selected' : ''); ?>

                                                        <?php endif; ?> value="JD">
                                                        Janda/Duda
                                                    </option>
                                                </select>
                                                <?php $__errorArgs = ['status_pernikahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="help-block">
                                                    <ul role="alert">
                                                        <li><?php echo e($message); ?></li>
                                                    </ul>
                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Jumlah Tanggungan','field' => 'jml_tanggungan','icon' => 'feather icon-users','value' => ''.e($anggota->jml_tanggungan).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Jumlah Tanggungan','field' => 'jml_tanggungan','icon' => 'feather icon-users','value' => ''.e($anggota->jml_tanggungan).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Nama Pasangan','field' => 'nama_pasangan','icon' => 'feather icon-user','value' => ''.e($anggota->nama_pasangan).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Nama Pasangan','field' => 'nama_pasangan','icon' => 'feather icon-user','value' => ''.e($anggota->nama_pasangan).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-6">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Pekerjaan Pasangan','field' => 'pekerjaan_pasangan','icon' => 'feather icon-anchor','value' => ''.e($anggota->pekerjaan_pasangan).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Pekerjaan Pasangan','field' => 'pekerjaan_pasangan','icon' => 'feather icon-anchor','value' => ''.e($anggota->pekerjaan_pasangan).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Nama Ibu Kandung','field' => 'nama_ibu','icon' => 'feather icon-user','value' => ''.e($anggota->nama_ibu).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Nama Ibu Kandung','field' => 'nama_ibu','icon' => 'feather icon-user','value' => ''.e($anggota->nama_ibu).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Nama Saudara Tidak Serumah','field' => 'nama_saudara','icon' => 'feather icon-user','value' => ''.e($anggota->nama_saudara).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Nama Saudara Tidak Serumah','field' => 'nama_saudara','icon' => 'feather icon-user','value' => ''.e($anggota->nama_saudara).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-12">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'No. HP','field' => 'no_hp','icon' => 'feather icon-phone','value' => ''.e($anggota->no_hp).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'No. HP','field' => 'no_hp','icon' => 'feather icon-phone','value' => ''.e($anggota->no_hp).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Data Alamat</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-group  <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <fieldset class="form-label-group mb-0">
                                                <textarea autocomplete="off" data-length=100 class="form-control char-textarea" name="alamat" id="alamat" rows="3" placeholder="Alamat Sesuai KTP"><?php if(!empty(old('alamat'))): ?><?php echo e(old('alamat')); ?><?php else: ?><?php echo e($anggota->alamat); ?><?php endif; ?></textarea>
                                            </fieldset>
                                            <small class="counter-value float-right"><span class="char-count">0</span> /
                                                100
                                            </small>
                                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="help-block">
                                                <ul role="alert">
                                                    <li><?php echo e($message); ?></li>
                                                </ul>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group  <?php $__errorArgs = ['id_propinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <select name="id_propinsi" id="id_propinsi" class="form-control">
                                                <option value="">Propinsi</option>
                                                <?php $__currentLoopData = $propinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(isset($anggota->id_propinsi)): ?> <?php if(old('id_propinsi')): ?>
                                                    <?php echo e(old('id_propinsi') == $p->id ? 'selected' : ''); ?> <?php else: ?>
                                                    <?php echo e($anggota->id_propinsi == $p->id ? 'selected' : ''); ?> <?php endif; ?> <?php else: ?>
                                                    <?php echo e(old('id_propinsi') == $p->id ? 'selected' : ''); ?>

                                                    <?php endif; ?> <?php echo e(old('id_propinsi') == $p->id ? 'selected' : ''); ?> value="<?php echo e($p->id); ?>">
                                                    <?php echo e($p->prov_name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['id_propinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="help-block">
                                                <ul role="alert">
                                                    <li><?php echo e($message); ?></li>
                                                </ul>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group  <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <select name="id_kota" id="id_kota" class="form-control">
                                                <option value="">Kabupaten/Kota</option>
                                            </select>
                                            <?php $__errorArgs = ['id_kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="help-block">
                                                <ul role="alert">
                                                    <li><?php echo e($message); ?></li>
                                                </ul>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group <?php $__errorArgs = ['id_kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"">
                                        <select name=" id_kecamatan" id="id_kecamatan" class="form-control">
                                            <option value="">Kecamatan</option>
                                            </select>
                                            <?php $__errorArgs = ['id_kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="help-block">
                                                <ul role="alert">
                                                    <li><?php echo e($message); ?></li>
                                                </ul>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group <?php $__errorArgs = ['id_kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <select name="id_kelurahan" id="id_kelurahan" class="form-control">
                                                <option value="">Kelurahan</option>
                                            </select>
                                            <?php $__errorArgs = ['id_kelurahan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="help-block">
                                                <ul role="alert">
                                                    <li><?php echo e($message); ?></li>
                                                </ul>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-4">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputtext','data' => ['label' => 'Kode Pos','field' => 'kode_pos','icon' => 'feather icon-codepen','value' => ''.e($anggota->kode_pos).'']]); ?>
<?php $component->withName('inputtext'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Kode Pos','field' => 'kode_pos','icon' => 'feather icon-codepen','value' => ''.e($anggota->kode_pos).'']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group <?php $__errorArgs = ['status_tinggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                            <select name="status_tinggal" id="status_tinggal" class="form-control">
                                                <option value="">Status Tinggal</option>
                                                <option <?php if(isset($anggota->status_tinggal)): ?> <?php if(old('status_tinggal')): ?>
                                                    <?php echo e(old('status_tinggal') == 'MS' ? 'selected' : ''); ?> <?php else: ?>
                                                    <?php echo e($anggota->status_tinggal == 'MS' ? 'selected' : ''); ?> <?php endif; ?> <?php else: ?>
                                                    <?php echo e(old('status_tinggal') == 'MS' ? 'selected' : ''); ?>

                                                    <?php endif; ?> value="MS">
                                                    Milik Sendiri
                                                </option>
                                                <option <?php if(isset($anggota->status_tinggal)): ?> <?php if(old('status_tinggal')): ?>
                                                    <?php echo e(old('status_tinggal') == 'MK' ? 'selected' : ''); ?> <?php else: ?>
                                                    <?php echo e($anggota->status_tinggal == 'MK' ? 'selected' : ''); ?> <?php endif; ?> <?php else: ?>
                                                    <?php echo e(old('status_tinggal') == 'MK' ? 'selected' : ''); ?>

                                                    <?php endif; ?> value="MK">
                                                    Milik Keluarga
                                                </option>
                                                <option <?php if(isset($anggota->status_tinggal)): ?> <?php if(old('status_tinggal')): ?>
                                                    <?php echo e(old('status_tinggal') == 'S' ? 'selected' : ''); ?> <?php else: ?>
                                                    <?php echo e($anggota->status_tinggal == 'S' ? 'selected' : ''); ?> <?php endif; ?> <?php else: ?>
                                                    <?php echo e(old('status_tinggal') == 'S' ? 'selected' : ''); ?>

                                                    <?php endif; ?> value="S">
                                                    Sewa / Kontrak
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['status_tinggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="help-block">
                                                <ul role="alert">
                                                    <li><?php echo e($message); ?></li>
                                                </ul>
                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary mr-1 mb-1">Submit</button>
                                        <button type="reset" class="btn btn-outline-warning mr-1 mb-1">Reset</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('myscript'); ?>
<script>
    $(function() {

        function loadkota() {
            var id_propinsi = $("#id_propinsi").val();
            var id_kota = "<?php echo e($anggota->id_kota); ?>";
            //alert(id_kota);
            $.ajax({
                type: 'POST'
                , url: '/loaddata/getkota'
                , data: {
                    _token: "<?php echo e(csrf_token()); ?>"
                    , id_propinsi: id_propinsi
                    , id_kota: id_kota
                }
                , cache: false
                , success: function(respond) {
                    $("#id_kota").html(respond);
                }
            });
        }

        $("#id_propinsi").change(function() {
            loadkota();
        });

        function loadkecamatan() {
            var kota = $("#id_kota").val();
            var id_kota = "";
            if (kota == "") {
                id_kota = "<?php echo e($anggota->id_kota); ?>";
            } else {
                id_kota = kota
            }
            var id_kecamatan = "<?php echo e($anggota->id_kecamatan); ?>";
            //alert(id_kota);
            $.ajax({
                type: 'POST'
                , url: '/loaddata/getkecamatan'
                , data: {
                    _token: "<?php echo e(csrf_token()); ?>"
                    , id_kota: id_kota
                    , id_kecamatan: id_kecamatan
                }
                , cache: false
                , success: function(respond) {
                    $("#id_kecamatan").html(respond);
                }
            });
        }

        function loadkelurahan() {
            var kecamatan = $("#id_kecamatan").val();
            var id_kecamatan = "";
            if (kecamatan == "") {
                id_kecamatan = "<?php echo e($anggota->id_kecamatan); ?>";
            } else {
                id_kecamatan = kecamatan;
            }

            var id_kelurahan = "<?php echo e($anggota->id_kelurahan); ?>";
            $.ajax({
                type: 'POST'
                , url: '/loaddata/getkelurahan'
                , data: {
                    _token: "<?php echo e(csrf_token()); ?>"
                    , id_kecamatan: id_kecamatan
                    , id_kelurahan: id_kelurahan
                }
                , cache: false
                , success: function(respond) {
                    $("#id_kelurahan").html(respond);
                }
            });
        }

        $("#id_kota").change(function() {
            loadkecamatan();
        });
        loadkota();
        loadkecamatan();
        loadkelurahan();
        $("#id_kecamatan").change(function() {
            loadkelurahan();
        });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.midone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kopontren\resources\views/anggota/edit.blade.php ENDPATH**/ ?>